﻿using Microsoft.EntityFrameworkCore;
namespace TrueLedger.Models
{
    public class EmployeeDbContext : DbContext
    {
        public EmployeeDbContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<Batch> Batches { get; set; }
    }
}